# SR AI Voice Studio — Professional 1.1 (build repair)
Developer: Shahriar Rahman · SR Creation Farm · © 2026

## Build on GitHub (phone friendly)
1. In the existing GitHub repository, replace the old ZIP (do not rename the new ZIP). Upload `SR_AI_Voice_Studio_Pro_Source.zip` unchanged to the repository root.
2. Replace `.github/workflows/build-apk.yml` in full using the supplied separate workflow. Commit it to main/master. The ZIP already contains the same workflow for users who upload the extracted source instead.
3. Actions → Build SR AI Voice Studio APK → Run workflow. Select main/master. The workflow also runs on pushes.
4. Download the artifact `SR-AI-Voice-Studio-Pro-APK`, extract it and install `SR-AI-Voice-Studio-Pro.apk`.

The workflow downloads the native AAR and nine model archives on GitHub, then packages them as Android assets. The source ZIP does not contain the large model weights. The installed app has no Internet permission and does not need another model download or API key. Build downloads are required. Allow substantial storage (APK plus one extracted voice pack) and time; actual APK size depends on upstream archives. Android 8+, 64-bit ARM or x86_64. At least 4–6 GB RAM recommended. The first use of each pack copies its files into private storage and initializes the CPU engine. The previous pack's extracted files are removed when switching. Debug-signed APK is for testing; for permanent updates use a stable release keystore. Never commit keystore passwords.

## Features
- Seven languages, nine model packs; dynamic speaker count and speaker-ID selection. US English LibriTTS-R has a large speaker inventory. Bengali Mimic3 is multilingual-speaker Bengali; Bangladesh-specific accent is not verified.
- Generate from a script or TXT; audition a sample; adjustable generation speed; multi-speaker dialogue with one `ID: text` line per turn (same model). 8,000 characters and up to ten minutes of output; split long scripts.
- Voice presets: deep, childlike, robotic, cinematic, soft, news, story, horror, telephone-like. These are DSP transformations, not separate age/emotion models. Pitch control also changes duration. The noise gate is not AI denoising.
- Waveform, playback, mic recording, PCM16 WAV import, trim, merge, looped background WAV mix at 25%, equalization-style bass/treble, fade, normalization, echo and room effect, bounded clip undo/redo, save and delete local WAV projects. Apply effects to update the preview. Projects store rendered audio, not full editable timelines.
- WAV and AAC/M4A (96/128/192 kbps) export to Android document picker. No MP3/FLAC/OGG output, reference voice cloning, trained emotion synthesis, automatic video dubbing, or separate batch export in this version.
- Developer profile and external links (these open a browser; generation stays offline).

## Local build
Install JDK 17, Android SDK 35/build-tools 35.0.0, Gradle 8.9, Python 3.12 and curl. Run `python tools/prepare_models.py`, then `gradle :app:assembleDebug :app:lintDebug`.

## Verification
`kotlinc app/src/main/java/com/srcreationfarm/voicestudio/Audio.kt tests/AudioSmoke.kt -include-runtime -d /tmp/audio-test.jar && java -jar /tmp/audio-test.jar`
The JVM audio smoke test passed (WAV round trip, trim, join, resampling, mixing, FX bounds and fades). XML/JSON/YAML syntax and ZIP integrity checked. Android SDK/Gradle and direct external downloads were unavailable in the generation environment, so the Android build, model download/inference, AAC encoding, recording and device UI have not been run. Version 1.1 removes android-actions/setup-android@v3 and uses the hosted runner SDK, installing only API 35 and build-tools 35.0.0 if missing. It selects the corrected ZIP by exact filename and checks the source version. It validates the AAR and model files, compiles Kotlin before downloading models, then builds, lints, verifies APK model inventory, ABI libraries, absence of INTERNET permission, and signature. These CI checks run on GitHub, not locally. They do not prove runtime behavior. The four local synthetic model-preparation tests validate file selection, extraction, AAR shape, and traversal rejection; they do not validate real model inference. Test in airplane mode: generate a Bengali sample, switch to English and choose a second speaker, record 5 seconds, trim, export both formats and reopen. If the workflow fails, send the first failing step and stack trace.

## Third party resources / license review
Sherpa-ONNX native library: https://github.com/k2-fsa/sherpa-onnx (Apache-2.0; dependencies may have separate terms). AAR version 1.12.23 from csukuangfj2/sherpa-onnx-libs, revision 01e3ced56f601a09425296507877b4c878b090aa. The selected model IDs are in `tools/models.json` and sourced from Sherpa's `tts-models` release. See https://k2-fsa.github.io/sherpa/onnx/tts/all/index.html . Model licensing and training data terms vary, including Mimic3, Piper, eSpeak and individual datasets. The preparation script keeps license and README files present in archives; absence of a license in an archive does not grant redistribution rights. Before publishing or commercial use, review the original model cards, dataset terms and all third-party license obligations. This source package does not assert commercial clearance of all voices.
