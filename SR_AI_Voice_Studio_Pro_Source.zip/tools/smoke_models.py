#!/usr/bin/env python3
"""Test native VITS inference using the pinned Sherpa-ONNX v1.12.23 CLI."""
import json
import pathlib
import re
import shlex
import subprocess
import sys
import tempfile
import wave

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets/models'
SPEED = 1.06
ENGLISH = ['Welcome everyone.', 'Today let us explore how modern technology is making our everyday', 'lives simpler and more productive.', 'Tasks that once took hours can now be completed in', 'moments with the help of artificial intelligence.']
BENGALI = ['স্বাগতম।', 'আজ আমরা একটি সুন্দর গল্প শুনব।', 'বাংলাদেশের প্রকৃতি খুব সুন্দর এবং মনোরম।']
CASES = [('vits-piper-en_US-libritts_r-medium', 107, ENGLISH), ('vits-mimic3-bn-multi_low', 0, BENGALI), ('vits-coqui-bn-custom_female', 0, BENGALI), ('vits-syspin-bn-female', 0, BENGALI)]


def build_args(exe, folder, pack, sid, speed=SPEED):
    # In v1.12.23 the binary passes speed=1.0 to Generate(). Configure VITS
    # duration using length_scale, the reciprocal of the desired speech speed.
    args = [str(exe), '--vits-model='+str(folder/pack['model']),
            '--vits-tokens='+str(folder/pack['tokens']), '--sid='+str(sid),
            f'--vits-length-scale={1/speed:.8f}', '--num-threads=2',
            '--tts-max-num-sentences=-1', '--tts-silence-scale=0.35']
    if pack['dataDir']:
        args.append('--vits-data-dir='+str(folder/pack['dataDir']))
    if pack['lexicon']:
        args.append('--vits-lexicon='+str(folder/pack['lexicon']))
    if pack['ruleFsts']:
        args.append('--tts-rule-fsts='+','.join(str(folder/f) for f in pack['ruleFsts'].split(',')))
    return args


def check_cli(exe, args):
    # Query the actual downloaded binary. Help may return a nonzero status.
    help_result = subprocess.run([str(exe), '--help'], stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, text=True, timeout=30)
    registered = set(re.findall(r'(?m)^\s*--([\w-]+)\s*:', help_result.stdout))
    requested = {arg.split('=', 1)[0][2:] for arg in args if arg.startswith('--')}
    requested.add('output-filename')
    missing = requested - registered
    if missing:
        print(help_result.stdout, flush=True)
        raise RuntimeError('Pinned native CLI does not register: '+', '.join(sorted(missing)))


def verify_wav(wav, part, speed=SPEED):
    with wave.open(str(wav), 'rb') as w:
        if w.getnchannels() != 1 or w.getsampwidth() != 2 or w.getframerate() <= 0:
            raise RuntimeError(f'Unexpected WAV format: {wav}')
        duration = w.getnframes()/w.getframerate()
        if duration < max(.08, len(part.split())*.13/speed):
            raise RuntimeError(f'Unusually short audio: {duration:.3f}s for {part!r}')
        if not any(w.readframes(w.getnframes())):
            raise RuntimeError(f'Silent output: {part!r}')
    return duration


def run_case(exe, folder, pack, sid, parts, temp_dir):
    args = build_args(exe, folder, pack, sid)
    check_cli(exe, args)
    total = 0.0
    for i, part in enumerate(parts):
        wav = pathlib.Path(temp_dir)/f'{i}.wav'
        wav.unlink(missing_ok=True)
        cmd = args+['--output-filename='+str(wav), part]
        print(f'[{pack["id"]}] speaker={sid}, part {i+1}/{len(parts)}', flush=True)
        print(shlex.join(cmd), flush=True)
        subprocess.run(cmd, check=True, timeout=120)
        if not wav.is_file():
            raise RuntimeError(f'No WAV created: {pack["id"]}, part {i+1}')
        total += verify_wav(wav, part)
    if total <= (5 if pack['id'].startswith('vits-piper') else 2):
        raise RuntimeError(f'Total audio too short: {pack["id"]}: {total:.2f}s')
    print(f'PASS native model: {pack["id"]} speaker {sid}: {total:.2f} s across {len(parts)} parts', flush=True)
    return total


def main():
    exe = pathlib.Path(sys.argv[1]).resolve()
    models = {p['id']: p for p in json.loads((ASSETS/'catalog.json').read_text(encoding='utf-8'))}
    with tempfile.TemporaryDirectory() as td:
        for model, sid, parts in CASES:
            run_case(exe, ASSETS/model, models[model], sid, parts, td)
    print('PASS: all four native regression cases', flush=True)


if __name__ == '__main__':
    main()
