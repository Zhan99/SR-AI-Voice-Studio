"""Check packaged model inventory and native libraries; no Android device required."""
import json
import pathlib
import sys
import zipfile

with zipfile.ZipFile(sys.argv[1]) as apk:
    assert apk.testzip() is None, 'Corrupted APK ZIP'
    names = set(apk.namelist())
    def present(name):
        assert name in names and apk.getinfo(name).file_size > 0, 'Missing/empty APK entry: ' + name
    for name in ('AndroidManifest.xml', 'classes.dex', 'assets/models/catalog.json'):
        present(name)
    catalog = json.loads(apk.read('assets/models/catalog.json'))
    expected = json.loads((pathlib.Path(__file__).parent / 'models.json').read_text(encoding='utf-8'))
    assert {p['id'] for p in catalog} == {p['id'] for p in expected} and len(catalog) == len(expected)
    for pack in catalog:
        prefix = 'assets/models/' + pack['id'] + '/'
        for name in [pack['model'], pack['tokens'], pack['dataDir'] + '/phontab', pack['lexicon'], *pack['ruleFsts'].split(',')]:
            if name:
                present(prefix + name)
    for abi in ('arm64-v8a', 'x86_64'):
        present(f'lib/{abi}/libsherpa-onnx-jni.so')
    print('PASS: all nine model packs, dex, manifest and both native ABIs')
