#!/usr/bin/env python3
"""Fetch fixed upstream neural voice packs at build time, not on Android."""
import json, pathlib, subprocess, tempfile, tarfile, shutil, zipfile, os
ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT/'app/src/main/assets/models'
AAR = ROOT/'app/libs/sherpa-onnx.aar'
BASE = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/'
AAR_URL = 'https://huggingface.co/csukuangfj2/sherpa-onnx-libs/resolve/01e3ced56f601a09425296507877b4c878b090aa/android/aar/sherpa-onnx-1.12.23.aar'
def fetch(url, path):
    subprocess.run(['curl','--fail','--location','--retry','3','--connect-timeout','30','--output',str(path),url],check=True)
def valid_aar(path):
    try:
        with zipfile.ZipFile(path) as z:
            return 'classes.jar' in z.namelist() and any(n.startswith('jni/arm64-v8a/') and n.endswith('libsherpa-onnx-jni.so') for n in z.namelist())
    except (OSError,zipfile.BadZipFile): return False
AAR.parent.mkdir(parents=True,exist_ok=True)
if not valid_aar(AAR):
    fetch(AAR_URL,AAR)
if not valid_aar(AAR): raise RuntimeError('Invalid sherpa AAR')
ASSETS.mkdir(parents=True,exist_ok=True)
items=json.loads((ROOT/'tools/models.json').read_text())
for item in items:
    name=item['id']; dst=ASSETS/name
    if dst.exists(): shutil.rmtree(dst)
    print('Preparing',name,flush=True)
    with tempfile.TemporaryDirectory() as td:
        tmp=pathlib.Path(td); tar=tmp/'model.tar.bz2'; fetch(BASE+name+'.tar.bz2',tar)
        with tarfile.open(tar) as t:
            t.extractall(tmp/'unpacked',filter='data')
        candidates=[p for p in (tmp/'unpacked').rglob('*.onnx') if (p.parent/'tokens.txt').is_file()]
        if not candidates: raise RuntimeError('Missing model/tokens: '+name)
        model=sorted(candidates,key=lambda p: ('int8' in p.name, len(p.name)))[0]
        shutil.copytree(model.parent,dst,symlinks=False)
        item['model']=model.name
        item['tokens']='tokens.txt'
        item['dataDir']='espeak-ng-data' if (dst/'espeak-ng-data').is_dir() else ''
        item['lexicon']='lexicon.txt' if (dst/'lexicon.txt').is_file() else ''
        if not item['dataDir'] and not item['lexicon']: raise RuntimeError('Missing phonemizer resources: '+name)
        item['ruleFsts']=','.join(p.name for p in sorted(dst.glob('*.fst')))
        # Remove empty directories (AssetManager cannot distinguish them from files).
        for p in sorted(dst.rglob('*'), key=lambda p: len(p.parts), reverse=True):
            if p.is_dir() and not any(p.iterdir()): p.rmdir()
        # Remove unused alternative ONNX weights, retain all license/phonemizer files.
        for p in dst.glob('*.onnx'):
            if p.name != model.name: p.unlink()
(ASSETS/'catalog.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
print('All',len(items),'packs prepared')
