#!/usr/bin/env python3
"""Fetch pinned native library and upstream neural voice packs at build time."""
import argparse
import json
import pathlib
import subprocess
import tempfile
import tarfile
import shutil
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'app/src/main/assets/models'
AAR = ROOT / 'app/libs/sherpa-onnx.aar'
BASE = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/'
AAR_URL = 'https://huggingface.co/csukuangfj2/sherpa-onnx-libs/resolve/01e3ced56f601a09425296507877b4c878b090aa/android/aar/sherpa-onnx-1.12.23.aar'
ABIS = ('arm64-v8a', 'x86_64')


def fetch(url, path):
    print('Downloading', url, flush=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_name(path.name + '.part')
    try:
        subprocess.run(['curl', '--fail', '--location', '--retry', '4', '--retry-all-errors', '--connect-timeout', '30', '--max-time', '1200', '--output', str(partial), url], check=True)
        if not partial.stat().st_size:
            raise RuntimeError('Empty download: ' + url)
        partial.replace(path)
    finally:
        partial.unlink(missing_ok=True)


def valid_aar(path):
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            return (z.testzip() is None and 'classes.jar' in names and
                    all(f'jni/{abi}/libsherpa-onnx-jni.so' in names for abi in ABIS))
    except (OSError, zipfile.BadZipFile):
        return False


def prepare_aar():
    if not valid_aar(AAR):
        fetch(AAR_URL, AAR)
    if not valid_aar(AAR):
        raise RuntimeError('Invalid sherpa AAR or missing supported ABI')


def model_filename(name):
    if name.startswith(('vits-coqui-', 'vits-syspin-')):
        return 'model.onnx'
    for prefix in ('vits-piper-', 'vits-mimic3-'):
        if name.startswith(prefix):
            return name[len(prefix):] + '.onnx'
    raise ValueError('Unsupported model: ' + name)


def unpack_model(archive, output, item):
    name = item['id']
    expected = model_filename(name)
    with tempfile.TemporaryDirectory() as td:
        unpacked = pathlib.Path(td)
        with tarfile.open(archive, 'r:*') as tar:
            tar.extractall(unpacked, filter='data')
        candidates = [p for p in unpacked.rglob(expected) if (p.parent / 'tokens.txt').is_file()]
        if len(candidates) != 1:
            raise RuntimeError(f'{name}: expected exactly one {expected} with tokens.txt, got {len(candidates)}')
        model = candidates[0]
        dst = output / name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(model.parent, dst, symlinks=False)
        for p in dst.glob('*.onnx'):
            if p.name != expected:
                p.unlink()
        for p in sorted(dst.rglob('*'), key=lambda p: len(p.parts), reverse=True):
            if p.is_dir() and not any(p.iterdir()):
                p.rmdir()
        for filename in (expected, 'tokens.txt'):
            if not (dst / filename).stat().st_size:
                raise RuntimeError(f'{name}: empty {filename}')
        character = item.get('frontend') == 'character'
        if not character and not (dst / 'espeak-ng-data' / 'phontab').is_file():
            raise RuntimeError(f'{name}: missing eSpeak phonemizer data')
        return dict(item, model=expected, tokens='tokens.txt', dataDir='' if character else 'espeak-ng-data',
                    lexicon='lexicon.txt' if (dst / 'lexicon.txt').is_file() else '',
                    ruleFsts=','.join(p.name for p in sorted(dst.glob('*.fst'))))


def prepare_models():
    ASSETS.mkdir(parents=True, exist_ok=True)
    catalog = ASSETS / 'catalog.json'
    catalog.unlink(missing_ok=True)
    items = json.loads((ROOT / 'tools/models.json').read_text(encoding='utf-8'))
    assert len(items) == len({item['id'] for item in items}) == 11
    prepared = []
    for item in items:
        name = item['id']
        if item.get('filesBase'):
            dst = ASSETS / name
            if dst.exists():
                shutil.rmtree(dst)
            for filename in ('model.onnx', 'tokens.txt', 'LICENSE', 'ATTRIBUTION', 'voice.json', 'README.md'):
                fetch(item['filesBase'] + filename, dst / filename)
            meta = json.loads((dst / 'voice.json').read_text())
            assert meta['gender'] == 'female' and meta['speakers'] == 1
            assert (dst / 'model.onnx').stat().st_size > 1000000
            prepared.append(dict(item, model='model.onnx', tokens='tokens.txt', dataDir='', lexicon='', ruleFsts=''))
        else:
            with tempfile.TemporaryDirectory() as td:
                archive = pathlib.Path(td) / 'model.tar.bz2'
                fetch(BASE + name + '.tar.bz2', archive)
                prepared.append(unpack_model(archive, ASSETS, item))
        print('Ready:', name, flush=True)
    catalog.write_text(json.dumps(prepared, ensure_ascii=False, indent=2), encoding='utf-8')
    print('All', len(prepared), 'packs prepared')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--aar-only', action='store_true')
    group.add_argument('--models-only', action='store_true')
    args = parser.parse_args()
    if not args.models_only:
        prepare_aar()
    if not args.aar_only:
        prepare_models()
