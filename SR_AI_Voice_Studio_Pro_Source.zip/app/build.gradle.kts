plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.srcreationfarm.voicestudio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.srcreationfarm.voicestudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.4-pro"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("onnx", "bin", "fst") }
    buildTypes { release { isMinifyEnabled = false } }
}
dependencies { implementation(files("libs/sherpa-onnx.aar")) }
