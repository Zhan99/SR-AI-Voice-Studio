package com.srcreationfarm.voicestudio
import android.media.*
import java.io.File
import java.nio.ByteOrder
import kotlin.math.roundToInt
object Encoder {
    fun m4a(c:Clip,file:File,bitrate:Int){
        val clip=Audio.resample(c,44100); val codec=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);var mux:MediaMuxer?=null;var started=false
        try{val fmt=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,clip.rate,1);fmt.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);fmt.setInteger(MediaFormat.KEY_BIT_RATE,bitrate);fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,16384);codec.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);codec.start();val m=MediaMuxer(file.absolutePath,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);mux=m;var track=-1;var pos=0;var eosIn=false;var eosOut=false;val info=MediaCodec.BufferInfo();var idle=0
            while(!eosOut){var progress=false;if(!eosIn){val idx=codec.dequeueInputBuffer(10000);if(idx>=0){val b=codec.getInputBuffer(idx)!!;b.clear();b.order(ByteOrder.LITTLE_ENDIAN);val n=minOf(b.remaining()/2,clip.samples.size-pos);for(i in 0 until n)b.putShort((clip.samples[pos+i].coerceIn(-1f,1f)*32767).roundToInt().toShort());val pts=pos*1000000L/clip.rate;pos+=n;eosIn=pos==clip.samples.size;codec.queueInputBuffer(idx,0,n*2,pts,if(eosIn)MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0);progress=true}}
                val out=codec.dequeueOutputBuffer(info,10000);when{out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED->{track=m.addTrack(codec.outputFormat);m.start();started=true;progress=true};out>=0->{val b=codec.getOutputBuffer(out)!!;if(info.size>0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG==0){check(started);b.position(info.offset);b.limit(info.offset+info.size);m.writeSampleData(track,b,info)};eosOut=info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0;codec.releaseOutputBuffer(out,false);progress=true}}
                idle=if(progress)0 else idle+1;check(idle<500){"AAC encoder stalled"}
            }
        }finally{try{codec.stop()}catch(_:Exception){};codec.release();try{if(started)mux?.stop()}finally{mux?.release()}}
    }
}
