package com.srcreationfarm.voicestudio

import android.content.Context
import com.k2fsa.sherpa.onnx.*
import org.json.JSONArray
import java.io.File

data class VoicePack(val id:String,val label:String,val lang:String,val sample:String,val model:String,val tokens:String,val dataDir:String,val lexicon:String,val ruleFsts:String)
class Neural(private val context:Context){
    val packs:List<VoicePack> = context.assets.open("models/catalog.json").bufferedReader().use { r -> val a=JSONArray(r.readText());(0 until a.length()).map { i -> val o=a.getJSONObject(i); VoicePack(o.getString("id"),o.getString("label"),o.getString("lang"),o.getString("sample"),o.getString("model"),o.getString("tokens"),o.getString("dataDir"),o.getString("lexicon"),o.getString("ruleFsts")) } }
    private var engine:OfflineTts?=null
    private var active=""
    private fun copyAssets(path:String,target:File){ val children=context.assets.list(path).orEmpty();if(children.isEmpty()){target.parentFile?.mkdirs();context.assets.open(path).use{input->target.outputStream().use{input.copyTo(it)}}}else{target.mkdirs();for(child in children)copyAssets("$path/$child",File(target,child))} }
    fun open(pack:VoicePack):Int {
        if(active==pack.id && engine!=null)return engine!!.numSpeakers()
        close()
        val root=File(context.noBackupFilesDir,"neural-v1"); root.mkdirs();val dir=File(root,pack.id);val marker=File(dir,".ready")
        if(!marker.exists()){dir.deleteRecursively();copyAssets("models/${pack.id}",dir);marker.writeText("ok")}
        root.listFiles()?.filter{it!=dir}?.forEach{it.deleteRecursively()}
        fun path(name:String)=if(name.isBlank())"" else File(dir,name).absolutePath
        val cfg=OfflineTtsConfig(model=OfflineTtsModelConfig(vits=OfflineTtsVitsModelConfig(model=path(pack.model),tokens=path(pack.tokens),dataDir=path(pack.dataDir),lexicon=path(pack.lexicon)),numThreads=Runtime.getRuntime().availableProcessors().coerceIn(2,4),debug=false,provider="cpu"),ruleFsts=pack.ruleFsts.split(',').filter{it.isNotBlank()}.joinToString(","){path(it)},maxNumSentences=1,silenceScale=.35f)
        val e=OfflineTts(config=cfg);engine=e;active=pack.id
        return e.numSpeakers().also{require(it>0){"No speakers in model"}}
    }
    fun generate(pack:VoicePack,text:String,speaker:Int,speed:Float):Clip {
        val n=open(pack);require(speaker in 0 until n){"Speaker must be 0–${n-1}"};val e=engine!!
        val chunks=text.trim().split(Regex("(?<=[.!?।！？])\\s*|\\n+")).flatMap { line -> if(line.length<=400)listOf(line) else line.chunked(400) }.filter{it.isNotBlank()}
        require(chunks.isNotEmpty()){ "Enter text first" }
        val parts=ArrayList<FloatArray>();var total=0L;var rate=0
        for(chunk in chunks){if(Thread.currentThread().isInterrupted)throw InterruptedException();val a=e.generate(chunk,sid=speaker,speed=speed);if(a.samples.isEmpty())continue;rate=a.sampleRate;if(parts.isNotEmpty()){val gap=FloatArray(rate/8);parts.add(gap);total+=gap.size};parts.add(a.samples);total+=a.samples.size;require(total<=rate*600L){"Maximum output is 10 minutes"}}
        require(total>0){"Model returned no audio"};val out=FloatArray(total.toInt());var at=0;for(p in parts){p.copyInto(out,at);at+=p.size};return Clip(out,rate)
    }
    fun close(){engine?.release();engine=null;active=""}
}
