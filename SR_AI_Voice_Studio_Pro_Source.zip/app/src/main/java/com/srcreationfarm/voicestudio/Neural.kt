package com.srcreationfarm.voicestudio

import android.content.Context
import com.k2fsa.sherpa.onnx.*
import org.json.JSONArray
import java.io.File

data class VoicePack(val id:String,val label:String,val lang:String,val sample:String,val model:String,val tokens:String,val dataDir:String,val lexicon:String,val ruleFsts:String)
class Neural(private val context:Context){
    val packs:List<VoicePack> = context.assets.open("models/catalog.json").bufferedReader().use { r -> val a=JSONArray(r.readText());(0 until a.length()).map { i -> val o=a.getJSONObject(i); VoicePack(o.getString("id"),o.getString("label"),o.getString("lang"),o.getString("sample"),o.getString("model"),o.getString("tokens"),o.getString("dataDir"),o.getString("lexicon"),o.getString("ruleFsts")) } }
    private var engine:OfflineTts?=null
    private var active=""
    private fun copyAssets(path:String,target:File){ val children=context.assets.list(path).orEmpty();if(children.isEmpty()){target.parentFile?.mkdirs();context.assets.open(path).use{input->target.outputStream().use{input.copyTo(it)}}}else{target.mkdirs();for(child in children)copyAssets("$path/$child",File(target,child))} }
    fun open(pack:VoicePack):Int {
        if(active==pack.id && engine!=null)return engine!!.numSpeakers().coerceAtLeast(1)
        close()
        val root=File(context.noBackupFilesDir,"neural-v1.1"); root.mkdirs();val dir=File(root,pack.id);val marker=File(dir,".ready")
        if(!marker.exists()){dir.deleteRecursively();copyAssets("models/${pack.id}",dir);marker.writeText("ok")}
        root.listFiles()?.filter{it!=dir}?.forEach{it.deleteRecursively()}
        fun path(name:String)=if(name.isBlank())"" else File(dir,name).absolutePath
        val cfg=OfflineTtsConfig(model=OfflineTtsModelConfig(vits=OfflineTtsVitsModelConfig(model=path(pack.model),tokens=path(pack.tokens),dataDir=path(pack.dataDir),lexicon=path(pack.lexicon)),numThreads=Runtime.getRuntime().availableProcessors().coerceIn(2,4),debug=false,provider="cpu"),ruleFsts=pack.ruleFsts.split(',').filter{it.isNotBlank()}.joinToString(","){path(it)},maxNumSentences=-1,silenceScale=.35f)
        val e=OfflineTts(config=cfg);val count=e.numSpeakers().coerceAtLeast(1);engine=e;active=pack.id
        return count
    }
    fun generate(pack:VoicePack,text:String,speaker:Int,speed:Float,dialogue:Boolean=false,progress:(Int,Int)->Unit={_,_->}):Clip {
        val parts=Generation.plan(text,speaker,dialogue)
        val n=open(pack); require(parts.all{it.speaker in 0 until n}){"Speaker must be 0–${n-1}"}; val e=engine!!
        return Generation.render(parts,speed,{part ->
            val a=e.generate(part.text,sid=part.speaker,speed=speed)
            if(a.samples.isEmpty()) null else Clip(a.samples,a.sampleRate)
        },progress)
    }
    fun close(){engine?.release();engine=null;active=""}
}
