package com.srcreationfarm.voicestudio

import kotlin.math.abs

data class SpeechPart(val speaker: Int, val text: String)

/** Small, word-boundary chunks keep native inference bounded. No speech chunk is silently skipped. */
object Generation {
    private val sentenceBreak = Regex("(?<=[!?।！？])|(?<=\\.)\\s+|[\\r\\n]+")
    private val whitespace = Regex("\\s+")
    private val spoken = Regex("[\\p{L}\\p{N}]")
    private fun words(text: String) = text.trim().split(whitespace).filter { it.isNotEmpty() }
    fun plan(text: String, speaker: Int, dialogue: Boolean): List<SpeechPart> {
        require(text.isNotBlank() && text.length <= 8000) { "Enter 1–8000 characters" }
        val turns = if (dialogue) text.lines().filter { it.isNotBlank() }.map { line ->
            val m = Regex("^\\s*(\\d+)\\s*:\\s*(.+)$").matchEntire(line) ?: error("Dialogue line must be ID: text")
            SpeechPart(m.groupValues[1].toInt(), m.groupValues[2])
        } else listOf(SpeechPart(speaker, text))
        val result = ArrayList<SpeechPart>()
        for (turn in turns) {
            val before = result.size
            for (sentence in turn.text.split(sentenceBreak)) {
                var chunk = ""
                var count = 0
                fun flush() {
                    if (spoken.containsMatchIn(chunk)) result.add(SpeechPart(turn.speaker, chunk))
                    chunk = ""; count = 0
                }
                for (word in words(sentence)) {
                    require(word.length <= 160) { "A word is too long; insert spaces or punctuation" }
                    if (count >= 10 || chunk.length + word.length + 1 > 140) flush()
                    chunk = if (chunk.isEmpty()) word else "$chunk $word"
                    count++
                }
                flush()
            }
            require(result.size > before) { "A script line contains no speakable text" }
        }
        return result
    }

    fun render(parts: List<SpeechPart>, speed: Float, synth: (SpeechPart) -> Clip?, progress: (Int, Int) -> Unit): Clip {
        require(parts.isNotEmpty() && speed.isFinite() && speed > 0f)
        val audio = ArrayList<FloatArray>()
        var rate = 0
        var total = 0L
        fun append(clip: Clip) {
            require(rate == 0 || rate == clip.rate) { "Model sample rate changed" }
            rate = clip.rate
            val gap = if (audio.isEmpty()) 0 else rate / 10
            require(total + gap + clip.samples.size <= rate * 600L) { "Maximum output is 10 minutes; split the script" }
            if (gap > 0) audio.add(FloatArray(gap))
            audio.add(clip.samples); total += gap + clip.samples.size
        }
        fun renderPart(part: SpeechPart) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException()
            val w = words(part.text).filter { spoken.containsMatchIn(it) }
            val clip = synth(part)
            // A conservative sanity check, not a speech-recognition/transcript guarantee.
            val valid = clip != null && clip.samples.all { it.isFinite() } &&
                clip.samples.any { abs(it) > 0.0001f } &&
                clip.seconds >= (w.size * 0.13 / speed).coerceAtLeast(0.08)
            if (valid) { append(requireNotNull(clip)); return }
            val tokens = words(part.text)
            if (tokens.size >= 2) {
                val middle = tokens.size / 2
                for (half in listOf(tokens.take(middle), tokens.drop(middle))) {
                    val text = half.joinToString(" ")
                    if (spoken.containsMatchIn(text)) renderPart(part.copy(text = text))
                }
            } else error("Voice model returned empty or unusually short audio for: ${part.text.take(60)}. Try another speaker.")
        }
        progress(0, parts.size)
        for ((index, part) in parts.withIndex()) {
            renderPart(part)
            progress(index + 1, parts.size)
        }
        val out = FloatArray(total.toInt()); var at = 0
        for (p in audio) { p.copyInto(out, at); at += p.size }
        return Clip(out, rate)
    }
}
