package com.srcreationfarm.voicestudio

import java.io.*
import kotlin.math.*

data class Clip(val samples: FloatArray, val rate: Int) {
    init { require(rate in 8000..96000 && samples.isNotEmpty()) }
    val seconds get() = samples.size.toDouble()/rate
}
data class Fx(val pitch: Float=1f, val volume: Float=1f, val bass: Float=0f, val treble: Float=0f, val echo: Float=0f, val reverb: Float=0f, val gate: Float=0f, val fade: Float=0f, val robot: Float=0f, val normalize: Boolean=true)
object Audio {
    fun resample(c: Clip, rate: Int): Clip = if (c.rate==rate) c else Clip(resize(c.samples, (c.samples.size.toDouble()*rate/c.rate).roundToInt().coerceAtLeast(1)), rate)
    private fun resize(x: FloatArray, n: Int): FloatArray = FloatArray(n) { i -> val p=i.toDouble()*x.size/n; val j=p.toInt().coerceAtMost(x.lastIndex); val f=(p-j).toFloat(); x[j]*(1-f)+x[(j+1).coerceAtMost(x.lastIndex)]*f }
    fun trim(c: Clip, start: Double, end: Double): Clip {
        require(start.isFinite() && end.isFinite() && start>=0 && end>start && end<=c.seconds+0.01) { "Invalid trim range" }
        val a=(start*c.rate).toInt().coerceIn(0,c.samples.lastIndex); val b=(end*c.rate).roundToInt().coerceIn(a+1,c.samples.size)
        return Clip(c.samples.copyOfRange(a,b),c.rate)
    }
    fun join(a: Clip,b: Clip, pause: Int=200): Clip {
        val x=resample(b,a.rate).samples; val gap=a.rate*pause.coerceIn(0,5000)/1000
        require(a.samples.size.toLong()+gap+x.size<=a.rate*600L) { "Maximum clip length is 10 minutes" }
        val out=FloatArray(a.samples.size+gap+x.size); a.samples.copyInto(out); x.copyInto(out,a.samples.size+gap); return Clip(out,a.rate)
    }
    fun mix(a: Clip,b: Clip, level: Float): Clip { val x=resample(b,a.rate).samples; return Clip(FloatArray(a.samples.size){ i -> (a.samples[i]+level*x[i%x.size]).coerceIn(-1f,1f)},a.rate) }
    fun process(c: Clip,f: Fx): Clip {
        // Resampling changes pitch and duration together; explicitly labelled in UI.
        val size=(c.samples.size/f.pitch.coerceIn(.5f,2f)).roundToInt().coerceAtLeast(1)
        require(size<=c.rate*600L){ "Pitch adjustment exceeds 10 minutes; trim the clip first" }
        val a=if(abs(f.pitch-1f)<0.005f)c.samples.copyOf() else resize(c.samples,size)
        var low=0f; var prev=0f
        val delay=(c.rate*.24).toInt().coerceAtLeast(1); val room=(c.rate*.045).toInt().coerceAtLeast(1)
        for(i in a.indices){
            val x=a[i]; low+=.04f*(x-low); val high=x-prev; prev=x
            var y=x+f.bass*low+f.treble*high
            if(abs(y)<f.gate) y*=.12f
            if(f.robot>0) y*=((1-f.robot)+f.robot*sin(2*PI*55*i/c.rate).toFloat())
            if(i>=delay) y+=f.echo*a[i-delay]
            if(i>=room) y+=f.reverb*a[i-room]
            a[i]=y
        }
        val peak=a.maxOf { abs(it) }; val gain=f.volume*(if(f.normalize && peak>0.00001f) .90f/peak else 1f)
        val fade=(f.fade*c.rate).toInt().coerceIn(0,a.size/2)
        for(i in a.indices){ val env=if(fade==0)1f else min(1f,min(i,a.lastIndex-i).toFloat()/fade); a[i]=(a[i]*gain*env).coerceIn(-1f,1f) }
        return Clip(a,c.rate)
    }
    fun writeWav(c: Clip, out: OutputStream) {
        val d=DataOutputStream(BufferedOutputStream(out)); fun le(n:Int){d.writeInt(Integer.reverseBytes(n))}; fun s(n:Int){d.writeShort(java.lang.Short.reverseBytes(n.toShort()).toInt())}
        val len=c.samples.size*2; d.writeBytes("RIFF");le(36+len);d.writeBytes("WAVEfmt ");le(16);s(1);s(1);le(c.rate);le(c.rate*2);s(2);s(16);d.writeBytes("data");le(len)
        for(x in c.samples) s((x.coerceIn(-1f,1f)*32767).roundToInt());d.flush()
    }
    fun readWav(input: InputStream): Clip {
        val d=DataInputStream(BufferedInputStream(input)); fun tag():String { val b=ByteArray(4);d.readFully(b);return String(b,Charsets.US_ASCII) }
        fun le()=Integer.reverseBytes(d.readInt())
        fun s()=java.lang.Short.reverseBytes(d.readShort()).toInt() and 65535
        require(tag()=="RIFF");le();require(tag()=="WAVE");var rate=0;var channels=0;var bits=0;var format=0
        while(true){val id=tag();val n=le();require(n in 0..120_000_000){"WAV chunk too large"}; when(id){
            "fmt "->{require(n>=16);format=s();channels=s();rate=le();le();s();bits=s();d.skipFully(n-16)}
            "data"->{require(format==1 && bits==16 && channels in 1..2 && rate in 8000..96000){"Only 16-bit PCM WAV mono/stereo supported"};val frames=n/(channels*2);require(frames in 1..rate*600){"Maximum WAV duration is 10 minutes"};val x=FloatArray(frames){var v=0f;repeat(channels){v+=java.lang.Short.reverseBytes(d.readShort()).toFloat()/32768};v/channels};return Clip(x,rate)}
            else->d.skipFully(n)
        };if(n%2==1)d.skipFully(1)}
    }
    private fun DataInputStream.skipFully(n:Int){var remain=n;while(remain>0){val k=skipBytes(remain);if(k==0){readByte();remain--}else remain-=k}}
}
