import com.srcreationfarm.voicestudio.*
fun main() {
    val english = "Welcome everyone. Today, let us explore how modern technology is making our everyday lives simpler and more productive. Tasks that once took hours can now be completed in moments with the help of artificial intelligence. Turning written text into natural speech saves valuable time and makes learning far more engaging. Whether you want to listen to an article, a story, or important notes on the go, voice tools bring your words to life. Keep learning new skills, embrace helpful technology, and move forward."
    val p = Generation.plan(english,107,false)
    check(p.size > 6 && p.all{it.speaker==107})
    check(p.joinToString(" "){it.text} == english)
    val bn = "স্বাগতম।আজ আমরা বাংলা ভাষায় একটি সুন্দর গল্প শুনব। " + "বাংলাদেশের প্রকৃতি খুব সুন্দর এবং মনোরম। ".repeat(12)
    val q = Generation.plan(bn,0,false)
    check(q.joinToString(""){it.text.filterNot(Char::isWhitespace)} == bn.filterNot(Char::isWhitespace))
    check(Generation.plan("0: Hello there!\n1: Good morning.",0,true).map{it.speaker} == listOf(0,1))
    val updates = mutableListOf<Int>(); val seen = mutableListOf<String>()
    val rate = 22050
    val result = Generation.render(p,1.06f,{ part -> seen.add(part.text);Clip(FloatArray(rate * part.text.split(' ').size / 3){.1f},rate) },{done,total->check(total==p.size);updates.add(done)})
    check(seen==p.map{it.text});check(result.seconds>20);check(updates==(0..p.size).toList())
    val retried = mutableListOf<String>()
    val recovered=Generation.render(listOf(SpeechPart(0,"one two three four")),1f,{part->retried.add(part.text);if(part.text.split(' ').size>2)null else Clip(FloatArray(rate){.2f},rate)},{_,_->})
    check(retried==listOf("one two three four","one two","three four"));check(recovered.seconds>2)
    check(runCatching{Generation.render(listOf(SpeechPart(0,"hello")),1f,{null},{_,_->})}.isFailure)
    check(runCatching{Generation.render(listOf(SpeechPart(0,"hello")),1f,{Clip(FloatArray(rate),rate)},{_,_->})}.isFailure)
    check(runCatching{Generation.plan("x".repeat(8001),0,false)}.isFailure)
    println("PASS: long English and Bangla coverage, speaker IDs, complete progress, retry, silent audio rejection and input limits")
}
