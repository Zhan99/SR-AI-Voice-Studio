import pathlib
import re
import unittest
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = ROOT / 'app/src/main/res'

class SourceCompatibilityTests(unittest.TestCase):
    def test_navigation_bar_api(self):
        gradle = (ROOT/'app/build.gradle.kts').read_text()
        min_sdk = int(re.search(r'minSdk\s*=\s*(\d+)', gradle).group(1))
        self.assertEqual(min_sdk, 26)
        attr = 'android:windowLightNavigationBar'
        for p in RES.glob('values*/*.xml'):
            match = re.search(r'-v(\d+)(?:-|$)', p.parent.name)
            version = int(match.group(1)) if match else min_sdk
            if any(e.get('name') == attr for e in ET.parse(p).iter('item')):
                self.assertGreaterEqual(version, 27, str(p))
        base = ET.parse(RES/'values/styles.xml').find('style')
        newer = ET.parse(RES/'values-v27/styles.xml').find('style')
        self.assertEqual(base.attrib, newer.attrib)
        self.assertEqual({e.get('name'):e.text for e in base}, {e.get('name'):e.text for e in newer if e.get('name') != attr})
        self.assertEqual(next(e.text for e in newer if e.get('name') == attr), 'false')
    def test_version_consistency(self):
        version = (ROOT/'tools/source-version.txt').read_text().strip()
        self.assertIn('versionName = "'+version+'"', (ROOT/'app/build.gradle.kts').read_text())
        workflow = (ROOT/'.github/workflows/build-apk.yml').read_text()
        self.assertIn("== '"+version+"'", workflow)
        self.assertLess(workflow.index(':app:lintDebug'), workflow.index('--models-only'))
        self.assertNotIn('android-actions/setup-android@v3', '\n'.join(x for x in workflow.splitlines() if not x.lstrip().startswith('#')))
    def test_xml_and_no_lint_suppression(self):
        for p in (ROOT/'app/src/main').rglob('*.xml'):
            ET.parse(p)
        gradle = (ROOT/'app/build.gradle.kts').read_text()
        self.assertNotRegex(gradle, r'abortOnError\s*=\s*false|disable\s*.*NewApi')
        for p in RES.rglob('*.xml'):
            self.assertNotIn('tools:ignore', p.read_text())
