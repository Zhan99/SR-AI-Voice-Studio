"""CLI invocation regression tests using a fake binary, not real inference."""
import pathlib, subprocess, sys, tempfile, unittest, wave
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
import smoke_models as smoke
FLAGS = ('vits-model','vits-tokens','sid','vits-length-scale','num-threads','tts-max-num-sentences','tts-silence-scale','vits-data-dir','vits-lexicon','tts-rule-fsts','output-filename')
PACK = dict(id='vits-coqui-bn-custom_female',model='model.onnx',tokens='tokens.txt',dataDir='',lexicon='',ruleFsts='')
class SmokeCliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.folder = pathlib.Path(self.temp.name); self.exe = self.folder/'fake-tts'
        self.exe.write_text(f'''#!{sys.executable}
import sys, wave
flags = {FLAGS!r}
if sys.argv[1:] == ['--help']:
    for flag in flags: print(' --'+flag+' : supported')
    sys.exit(0)
args = sys.argv[1:]
assert len([a for a in args if not a.startswith('--')]) == 1
options = dict(a[2:].split('=',1) for a in args[:-1])
assert set(options) <= set(flags), options
assert abs(float(options['vits-length-scale']) - 1/1.06) < 1e-7
assert args[-1] == 'আজ আমরা একটি সুন্দর গল্প শুনব।'
with wave.open(options['output-filename'], 'wb') as w:
    w.setparams((1,2,22050,0,'NONE','not compressed'))
    w.writeframes(b'\\x00\\x20' * 22050 * 3)
'''); self.exe.chmod(0o755)
    def test_native_flag_contract(self):
        pack = dict(PACK,dataDir='espeak-ng-data',lexicon='lexicon.txt',ruleFsts='a.fst,b.fst')
        args = smoke.build_args(self.exe,self.folder,pack,107)
        self.assertTrue(all(a[2:].split('=',1)[0] in FLAGS for a in args[1:]))
        self.assertIn('--sid=107',args); self.assertNotIn('--speed=1.06',args)
        smoke.check_cli(self.exe,args)
        with self.assertRaisesRegex(RuntimeError,'speed'): smoke.check_cli(self.exe,args+['--speed=1.06'])
    def test_subprocess_and_wav(self):
        self.assertEqual(smoke.run_case(self.exe,self.folder,PACK,0,['আজ আমরা একটি সুন্দর গল্প শুনব।'],self.folder),3.0)
    def test_fail_closed(self):
        s=self.exe.read_text(); self.exe.write_text(s.replace('args = sys.argv[1:]','sys.exit(9)\nargs = sys.argv[1:]'))
        with self.assertRaises(subprocess.CalledProcessError): smoke.run_case(self.exe,self.folder,PACK,0,['আজ আমরা একটি সুন্দর গল্প শুনব।'],self.folder)
    def test_silence_and_truncation(self):
        p=self.folder/'invalid.wav'
        for frames,expected in [(b'\x00\x00'*22050,'Silent'),(b'\x00\x20'*100,'short')]:
            with wave.open(str(p),'wb') as w:
                w.setparams((1,2,22050,0,'NONE','not compressed')); w.writeframes(frames)
            with self.assertRaisesRegex(RuntimeError,expected): smoke.verify_wav(p,'a sentence of words')
    def test_single_speaker_zero_metadata_handling(self):
        code=(ROOT/'app/src/main/java/com/srcreationfarm/voicestudio/Neural.kt').read_text()
        self.assertEqual(code.count('numSpeakers().coerceAtLeast(1)'),2)
