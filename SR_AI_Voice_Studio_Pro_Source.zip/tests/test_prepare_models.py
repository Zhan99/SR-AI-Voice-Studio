import io
import pathlib
import tarfile
import tempfile
import unittest
import zipfile
from tools.prepare_models import model_filename, unpack_model, valid_aar, ABIS

class ModelTests(unittest.TestCase):
    def test_names(self):
        self.assertEqual(model_filename('vits-mimic3-bn-multi_low'), 'bn-multi_low.onnx')
        self.assertEqual(model_filename('vits-piper-hi_IN-rohan-medium'), 'hi_IN-rohan-medium.onnx')
    def test_aar(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td)/'test.aar'
            with zipfile.ZipFile(p, 'w') as z:
                z.writestr('classes.jar', b'fake')
                for abi in ABIS:
                    z.writestr(f'jni/{abi}/libsherpa-onnx-jni.so', b'fake')
            self.assertTrue(valid_aar(p))
            p.write_bytes(b'invalid')
            self.assertFalse(valid_aar(p))
    def test_unpack(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td)
            archive = p/'test.tar.bz2'
            files = ['bn-multi_low.onnx', 'alternative.onnx', 'tokens.txt', 'espeak-ng-data/phontab', 'LICENSE']
            with tarfile.open(archive, 'w:bz2') as t:
                for name in files:
                    info = tarfile.TarInfo('pack/'+name); info.size = 4
                    t.addfile(info, io.BytesIO(b'test'))
            item = {'id':'vits-mimic3-bn-multi_low'}
            result = unpack_model(archive, p/'out', item)
            self.assertEqual(result['model'], 'bn-multi_low.onnx')
            self.assertTrue((p/'out'/item['id']/'LICENSE').exists())
            self.assertFalse((p/'out'/item['id']/'alternative.onnx').exists())
            with self.assertRaises(RuntimeError):
                unpack_model(archive, p/'out', {'id':'vits-piper-other'})
    def test_reject_traversal(self):
        with tempfile.TemporaryDirectory() as td:
            p = pathlib.Path(td)/'bad.tar'
            with tarfile.open(p, 'w') as t:
                i=tarfile.TarInfo('../escape'); i.size=1; t.addfile(i,io.BytesIO(b'x'))
            with self.assertRaises(tarfile.FilterError):
                unpack_model(p, p.parent/'out', {'id':'vits-mimic3-bn-multi_low'})
