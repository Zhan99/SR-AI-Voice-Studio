"""Run actual native Linux VITS inference before packaging; uses same runtime version as Android."""
import json
import pathlib
import subprocess
import sys
import tempfile
import wave

root = pathlib.Path(__file__).resolve().parents[1]
assets = root / 'app/src/main/assets/models'
models = {p['id']: p for p in json.loads((assets/'catalog.json').read_text())}
exe = pathlib.Path(sys.argv[1]).resolve()
english = ['Welcome everyone.', 'Today let us explore how modern technology is making our everyday', 'lives simpler and more productive.', 'Tasks that once took hours can now be completed in', 'moments with the help of artificial intelligence.']
bengali = ['স্বাগতম।', 'আজ আমরা একটি সুন্দর গল্প শুনব।', 'বাংলাদেশের প্রকৃতি খুব সুন্দর এবং মনোরম।']
cases = [('vits-piper-en_US-libritts_r-medium', 107, english), ('vits-mimic3-bn-multi_low', 0, bengali), ('vits-coqui-bn-custom_female', 0, bengali), ('vits-syspin-bn-female', 0, bengali)]
with tempfile.TemporaryDirectory() as td:
    for model, sid, parts in cases:
        p = models[model]; folder = assets/model
        args = [str(exe), '--vits-model='+str(folder/p['model']), '--vits-tokens='+str(folder/p['tokens']), '--sid='+str(sid), '--speed=1.06', '--num-threads=2', '--tts-max-num-sentences=-1']
        if p['dataDir']: args.append('--vits-data-dir='+str(folder/p['dataDir']))
        if p['lexicon']: args.append('--vits-lexicon='+str(folder/p['lexicon']))
        if p['ruleFsts']: args.append('--tts-rule-fsts='+','.join(str(folder/f) for f in p['ruleFsts'].split(',')))
        total = 0
        for i, part in enumerate(parts):
            wav = pathlib.Path(td)/f'{i}.wav'
            wav.unlink(missing_ok=True)
            subprocess.run(args+['--output-filename='+str(wav), part], check=True, timeout=120)
            with wave.open(str(wav),'rb') as w:
                duration = w.getnframes()/w.getframerate()
                assert duration >= max(.08, len(part.split())*.13/1.06), (model, part, duration)
                assert any(w.readframes(w.getnframes())), (model, 'silent output')
                total += duration
        assert total > (5 if model.startswith('vits-piper') else 2), (model, total)
        print(f'PASS native model: {model} speaker {sid}: {total:.2f} s across {len(parts)} parts', flush=True)
